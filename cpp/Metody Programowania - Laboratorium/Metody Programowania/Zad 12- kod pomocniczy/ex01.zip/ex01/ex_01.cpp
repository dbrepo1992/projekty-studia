#include <iostream>
#include "lin_win.h"


int main() {
  #ifdef _WIN64  // _WIN32 and _WIN64 too
    SetConsoleOutputCP(CP_UTF8);
    #define LIBRARY_NAME "./lib_01.dll"
  #else
    #define LIBRARY_NAME "./lib_01.so"
  #endif  
/* 
Poeksperymentuj!
  Zamiast definiowania nazwy biblioteki jako stałej
  spróbuj przekazać nazwę biblioteki jako parametr programu.
*/

  try{
    HINSTANCE lib_ptr = LOAD_LIB( LIBRARY_NAME );
    if (!lib_ptr)
      throw LOAD_LIB_ERROR;
 
    using fun1 = void(*)();   
    //fun1 to wskaźnik do funkcji, którą możesz zadeklarować i nazwać jak chcesz;
    //bylebyś później używał(a) tej nazwy i takich jak trzeba argumentów.
    //W tym przykładzie funkcję, która nic nie zwraca 
    //i nie przyjmuje żadnych argumentów nazwano "main_task".         
    fun1 main_task = (fun1)LOAD_SYM(lib_ptr, "main_task");
    if (!main_task) 
      throw LOAD_SYM_ERROR;

    main_task(); 

    CLOSE_LIB(lib_ptr);
  }
  catch (const std::string& e){
    std::cout << e;
  }
  catch (...){
    std::cout << "Oooops coś poszło nie tak." << std::endl;
  }

  #ifdef _WIN32
    system("PAUSE");
  #endif // _WIN32 and _WIN64 too
  return 0;
}
