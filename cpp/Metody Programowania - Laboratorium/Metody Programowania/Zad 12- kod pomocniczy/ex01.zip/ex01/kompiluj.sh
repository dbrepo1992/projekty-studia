#!/bin/bash
g++ -Wall -std=c++20 -pedantic -shared -fPIC lib_01.cpp -o lib_01.so
g++ -Wall -std=c++20 -pedantic ex_01.cpp -o ex_01.out -ldl
