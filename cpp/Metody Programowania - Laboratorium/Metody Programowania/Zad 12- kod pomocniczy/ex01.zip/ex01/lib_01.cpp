#include <iostream>
#include "lin_win.h"

void hello_1(){
  std::cout << "Hello dynamically linked World.\n";
}
 
EXTERN_C void main_task(){
  
  hello_1();

}
