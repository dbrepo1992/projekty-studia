#ifndef __LIN_WIN_H__
#define __LIN_WIN_H__
//---------------------------------------------
#ifdef __linux__ /* Linux */
  #include <dlfcn.h>
  #define HINSTANCE void* 
  #define EXTERN_C extern "C"
  #define LOAD_LIB(name) dlopen(name, RTLD_LAZY)
  #define LOAD_SYM(lib,name) dlsym(lib,name)
  #define LOAD_LIB_ERROR std::string( { dlerror() } ) + '\n'
  #define LOAD_SYM_ERROR std::string( { dlerror() } ) + '\n'
  #define CLOSE_LIB(lib_ptr) dlclose (lib_ptr)
#endif 

#ifdef _WIN32  
  #include <windows.h>
  /* HINSTANCE is defined in windows.h */
  #define EXTERN_C extern "C" /* EXTERN_C __declspec(dllexport) */
  #define LOAD_LIB(name) LoadLibrary(name)
  #define LOAD_SYM(lib,name) GetProcAddress(lib,name)
  #define LOAD_LIB_ERROR std::string( "ERROR: unable to load DLL\n" )
  #define LOAD_SYM_ERROR std::string("ERROR: unable to find DLL function\n" )
  #define CLOSE_LIB(lib_ptr) FreeLibrary(lib_ptr)
#endif
//---------------------------------------------
#endif