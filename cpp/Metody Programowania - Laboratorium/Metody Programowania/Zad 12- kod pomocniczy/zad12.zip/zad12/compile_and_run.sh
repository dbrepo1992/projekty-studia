#!/bin/bash
g++ -Wall -std=c++20 -pedantic -shared -fPIC lib_02.cpp -o lib_02.so
g++ -Wall -std=c++20 -pedantic -shared -fPIC lib_03.cpp -o lib_03.so
#
# z linkowaniem statycznej biblioteki koty.o
g++ -Wall -pedantic -std=c++20 koty.cpp -c
g++ -Wall -std=c++20 -pedantic -shared -fPIC koty.o lib_04.cpp -o lib_04.so
#
g++ -Wall -std=c++20 -pedantic zad12.cpp -o zad12.out -ldl
# pamiętaj o koniecznej (pod linuxem) fladze -ldl, której nie używa się pod Win
#
echo
echo "*** 1 (  ./zad12.out lib_02.so  )"
./zad12.out lib_02.so
echo
echo "*** 2 (  ./zad12.out lib_03.so  )"
./zad12.out lib_03.so
echo
echo "*** 3 (  ./zad12.out lib_04.so  )"
./zad12.out lib_04.so
