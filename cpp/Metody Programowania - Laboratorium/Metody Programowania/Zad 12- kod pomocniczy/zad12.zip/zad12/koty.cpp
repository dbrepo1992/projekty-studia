#include "koty.hpp"


std::ostream& kotto::result(std::ostream& out)const{
  // Tu popracuj sam(a).
  //
  // Dopuki nie zostanie wylosowana liczba równa wartości min należy wyświetlać tekst:
  //
  // Ala ma 9 kotów.
  // ...
  // Ala ma 2 koty.
  // ...
  // Ala ma jednego kota.
  //
  // z właściwymi dla danej liczby końcówkami wyrazu kot.
  // Liczby losowane mają być z przedziału <min, max>.   
}

std::ostream& operator<<(std::ostream& out , const kotto& ob){
  return ob.result(out);
}
