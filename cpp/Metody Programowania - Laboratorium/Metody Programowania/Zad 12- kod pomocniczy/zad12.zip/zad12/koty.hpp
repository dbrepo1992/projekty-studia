#ifndef _koty_hpp__
#define _koty_hpp__
//---------------------------------------------

#include <iostream>
#include <ctime>
 
class kotto{
  int min, max;
  public:
  kotto():min(1), max(10){ srand(time(NULL)); }
  kotto(int a, int b):min(a), max(b){ srand(time(NULL)); }
  std::ostream& result(std::ostream&)const; 
};

std::ostream& operator<<(std::ostream& out, const kotto& ob);
//---------------------------------------------
#endif
