#include <iostream>
#include "lin_win.h"

void hello_1(){
  std::cout << "\nHello dynamically linked World.\n";
}
 
EXTERN_C void main_task(){
  
  hello_1();

}
