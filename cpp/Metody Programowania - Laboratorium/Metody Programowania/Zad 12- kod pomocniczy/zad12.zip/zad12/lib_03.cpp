#include <iostream>
#include <cstring>
#include "lin_win.h"

constexpr void println(auto const & a) { std::cout << a << std::endl; }

class txt{
  std::string s;
 public:
  txt(const char* a="\0"):s(a){}
  bool operator >(const txt& a)const { return s.size() > a.s.size(); }
  bool operator <(const txt& a)const { return s.size() < a.s.size(); }
  friend std::ostream& operator<<(std::ostream&, const txt&);
};
std::ostream& operator<<(std::ostream& out, const txt& a){ return out << a.s; }

//-------------------------------------------------------------------------------

template<typename T>
inline
const T& Max(const T& a, const T& b){ return a>b?a:b; }

using specT =const char*;
template<>
inline
const specT& Max(const specT& a, const specT& b){
  return strcmp(a, b) > 0 ? a : b;
}

template<typename T, unsigned N>
T Max(const T (&tab)[N]){
  T tmp = tab[0];
  for (unsigned i = 1; i < N; ++i)
    if (tab[i] > tmp)
      tmp = tab[i];
  return tmp;
}

//-------------------------------------------------------------------------------


void hello_2(){
  println("\nWitaj w świecie dynamicznych bibliotek.");
}

void fun2(){
  using std::string;
  try{
    println( "\n---------------" );
    int    ti[] = {3, 5, 1, 4, 2, 0};
    double td[] = {2.71, 3.14, 0.866, 0.5};
    string ts[] = {"Ala", "ma", "kota"};
    txt    ttt[] = {txt("Ala"), txt("ma"), txt("kota")};
    txt    ttc[] = {"*****", "***", "*"};

    println( Max(ti) );
    println( Max(td) );
    println( Max(ts) );
    println( Max(ttt));
    println( Max(ttc));
    println( "\n---udało się---" );
  }
  catch (...){
    println( string("Oooops to się nie powinno zdarzyć.") );
  }
}

//-------------------------------------------------------------------------------

EXTERN_C void main_task(){

  hello_2();
  fun2();

}
