#include "koty.hpp"
#include "lin_win.h"

EXTERN_C void main_task(){

  std::cout << "Losowanie kotów - kończy się po wylosowaniu wartości\ndolnej granicy przedziału - domyślnie ustawianej na 1.\n";
  kotto ob1 ;

  std::cout << "\n----- A -----\n";
  std::cout << ob1;
  
  std::cout << "\n----- B -----\n";
  std::cout << ob1;

  kotto ob2(2,7);
  std::cout << "\n----- C -----\n";
  std::cout << ob2;

}
