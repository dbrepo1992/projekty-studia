#include <iostream>
#include "lin_win.h"


int main(int argc, char* argv[])try {
  #ifdef _WIN64  // _WIN32 and _WIN64 too
    SetConsoleOutputCP(CP_UTF8);
  #endif  

  try{
    
    //Korzystając z przykładu ex_01.cpp
    //napisz brakujący kod tak, 
    //by nazwy używanych bibliotek mogły być przekazywane 
    //jako parametr funkcji main()  
    
    main_task(); //To może być inna nazwa funkcji - jeśli tak chcesz.
    
    CLOSE_LIB(lib_ptr); 
  }
  catch (const std::string& e){
    std::cout << e;
  }

  #ifdef _WIN32
    system("PAUSE");
  #endif // _WIN32 and _WIN64 too
  return 0;
}
catch (...){
  std::cout << "Oooops coś poszło nie tak." << std::endl;
}
